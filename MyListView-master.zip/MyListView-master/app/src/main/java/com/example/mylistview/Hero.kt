package com.example.mylistview

import android.accounts.AuthenticatorDescription
import android.provider.ContactsContract

data class Hero(
    var photo: Int,
    var name: String,
    var description: String
)